
let index = 1;
async function createMailbox(useSpecify=false) {
  const res = await fetch('/api/create_mailaddress', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ use_specify: useSpecify })
  });
  const data = await res.json();
  const row = document.createElement('tr');
  row.innerHTML = `<td>${index++}</td><td>${data.mailaddress}</td><td id="code-${data.mailaddress}">查询中...</td>`;
  document.getElementById('result-table').appendChild(row);

  // 查询验证码
  const checkRes = await fetch('/api/check_top_mail', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      mailaddress: data.mailaddress,
      csrf_token: data.csrf_token,
      sessionhash: data.sessionhash
    })
  });
  const checkData = await checkRes.json();
  document.getElementById(`code-${data.mailaddress}`).innerText = checkData.code || '未获取';
}
