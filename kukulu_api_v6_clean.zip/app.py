from flask import Flask, request, jsonify
from kukulu import Kukulu
from token_manager import TokenManager
import logging, os, json, random

os.makedirs("logs", exist_ok=True)
logging.basicConfig(
    filename="logs/kukulu_api.log",
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)

# 加载自定义后缀池（每行一个）
CUSTOM_DOMAINS = []
try:
    with open("custom_domains.txt", "r", encoding="utf-8") as f:
        CUSTOM_DOMAINS = [line.strip() for line in f if line.strip()]
except Exception as e:
    logging.warning(f"[CONFIG] custom_domains.txt not found or unreadable: {e}")

app = Flask(__name__)
manager = TokenManager()

@app.route('/api/create_mailaddress', methods=['POST'])
def create_mailaddress():
    try:
        data = request.get_json(silent=True) or {}
        use_specify = data.get("use_specify", False)
        token = manager.get_token()
        kukulu = Kukulu(token['csrf_token'], token['sessionhash'])

        if use_specify and CUSTOM_DOMAINS:
            domain = random.choice(CUSTOM_DOMAINS)
            mail = kukulu.specify_address(domain)
            logging.info(f"[CREATE_CUSTOM] mail={mail} domain={domain} token={json.dumps(token)}")
        else:
            mail = kukulu.create_mailaddress()
            logging.info(f"[CREATE_AUTO] mail={mail} token={json.dumps(token)}")

        return jsonify({
            "mailaddress": mail,
            "csrf_token": token['csrf_token'],
            "sessionhash": token['sessionhash']
        })
    except Exception as e:
        logging.error(f"[CREATE_ERROR] {str(e)}")
        return jsonify({"error": "Failed to create mail", "details": str(e)}), 500

@app.route('/api/check_top_mail', methods=['POST'])
def check_top_mail():
    try:
        data = request.get_json()
        token = {"csrf_token": data["csrf_token"], "sessionhash": data["sessionhash"]}
        mailaddress = data["mailaddress"]

        for attempt in range(5):
            kukulu = Kukulu(token["csrf_token"], token["sessionhash"])
            result = kukulu.check_top_mail(mailaddress)
            if result:
                logging.info(f"[CODE_OK] mail={mailaddress} code={result} token={json.dumps(token)}")
                return jsonify({"code": result})
            else:
                logging.warning(f"[CODE_FAIL] attempt={attempt+1} mail={mailaddress} token={json.dumps(token)}")
            token = manager.rotate_token()

        logging.error(f"[CODE_FAIL_FINAL] mail={mailaddress}")
        return jsonify({"error": "Failed to get code after retries"}), 404
    except Exception as e:
        logging.error(f"[CHECK_ERROR] {str(e)}")
        return jsonify({"error": "Exception", "details": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)