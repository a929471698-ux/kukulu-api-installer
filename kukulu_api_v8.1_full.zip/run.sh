#!/bin/bash
source /root/kukulu_env/bin/activate
python app.py
